package za.co.entelect.challenge.enums;

import com.google.gson.annotations.SerializedName;

public enum PowerUpType {
    @SerializedName("HEALTH_PACK")
    HEALTH_PACK
}

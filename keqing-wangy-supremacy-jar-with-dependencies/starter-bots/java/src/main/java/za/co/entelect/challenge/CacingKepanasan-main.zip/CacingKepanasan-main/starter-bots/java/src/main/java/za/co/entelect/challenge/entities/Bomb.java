package za.co.entelect.challenge.entities;

import com.google.gson.annotations.SerializedName;

public class Bomb {
    @SerializedName("count")
    public int count;
}